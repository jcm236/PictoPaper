import os
from guizero import App, ListBox
def pictopaper():
    if os.path.exists("/usr/share/pictopaper/") == False:
        os.system('sudo mkdir /usr/share/pictopaper/')
    path = "/usr/share/pictopaper/"
    dir_list = os.listdir(path)
    
    app = App(title="PictoPaper", width= 300, height=400) 
    def setpic(value):
        os.system('pcmanfm --set-wallpaper ' + os.path.abspath("/usr/share/pictopaper/"+ value) )
    
    pics = ListBox(app, items=dir_list, command=setpic, width = 275, height=400)
    app.display()