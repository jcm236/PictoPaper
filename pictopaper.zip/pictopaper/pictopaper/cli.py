"""
The command-line interface for the downloader
"""
import argparse
from .pictopaper import pictopaper


def main():
    print("Starting PictoPaper...")
    pictopaper()
if __name__ == "__main__":
    main()